
      <footer class="bg-gray text-light footer-long">
        <div class="container">
          <div class="row">
            <div class="col-12 col-md-3">
              <p class="text-muted text-center">
                &copy; 2021 Derechos Reservados
                <br />
                
              </p>
            </div>
            <!--end of col-->
            <div class="col-12 col-md-9">
              <div class="col-auto text-sm-right">
              <ul class="list-inline">
                <li class="list-inline-item">
               
                </a>
                </li>
              </ul>
            </div>
            </div>
            <!--end of col-->
          </div>
          <!--end of row-->
        </div>
        <!--end of container-->
      </footer>