<div class="main-container" style="background-image:  url('assets/img/bienvenidos.jpg'); background-size: cover; height: 100%;  background-position-x: 25%;">
      <section class="fullwidth-split" >
        <div class="container">
          <div class="row no-gutters height-100">
            <div class="container">
                <div class="row justify-content-between align-items-center" style="margin-top:35%;">
                    <div class="col-12 col-md-6 mb-8">
                    </div>
                    <!--end of col-->
                    <div class="col-12 col-lg-5 mb-4 text-center text-md-right">
                        <h1 class="display-3 text-light" style="text-shadow: rgb(8, 0, 0) 2px 2px;">Bienvenido!</h1>
                        <h2 class="lead text-light" style="text-shadow: rgb(8, 0, 0) 2px 2px;">Envia tus facturas por compras de Productos Ramo realizadas, <spam style="color:#ffeb00;">entre el 15 de febrero y el 15 de marzo al WhatsApp +3223542797</spam> Y acumula puntos para llevarte fabulosos premios.</h2>
                
                    <div>
                        <a href="?action=login" class="btn btn-primary" style="background-color: #f2ce3e; color:black;"><i class="icon-login"></i> Ingresar</a>
                        <a href="?action=register" class="btn btn-primary" style="background-color: #f2ce3e; color:black;">Registrarme</a>

                    </div>
                    </div>
                    <!--end of col-->
                </div>
                <!--end of row-->
            </div>
            <!--end of container-->
            
          </div>
          <!--end of row-->
        </div>
        <!--end of container-->
      </section>
      <!--end of section-->
      <!-- Whatsapp button  -->
      <?php require_once 'modals/whatsapp.php'?>
    
</div>

     <!-- Required vendor scripts (Do not remove) -->
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/popper.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>

    
    
   